# The Hard Port — Brand Book

## One line
**We give a f*ck. We just don't care.**

We care about the work and the outcome. We do not care about the client's comfort, feelings, excuses or ego. Every word, layout and interaction gets checked against that split. If something makes the brand look like it wants to be liked, it is wrong.

## Who we are
The Hard Port (THP) is a no-bullshit media and strategy agency for small businesses that are "doing fine". Fine is the problem. We bring clarity, the client brings commitment.

"Hard a-port" is the command you shout to swing a ship hard before it hits the rocks. That is the whole company in one phrase.

Founder: Tarek H Ghosn, based in Lebanon. Site: thehardport.com. Instagram: @thehardport.

## The archetype
**The Uncompromising Navigator.** A strategic partner, not a helper.

Picture a veteran captain. She looks at a struggling studio owner or gym operator, points at the horizon and tells them the truth they have been avoiding. Calm, unshakeable and immune to excuses, drama and ego.

- **Voice:** pointed and hard. Level 2 to 3 on the aggression ladder. It never starts at level 4 and it never softens at the call to action.
- **What it does:** it punches the behaviour and hands the person a way out in the same breath. Example: "You are choosing to stay busy because being busy feels safer than fixing the system."
- **Posture:** we do not reassure. We demand clarity and put a system in place.
- **Philosophy:** we do not help. We do our job so yours gets easier.

## The model, for one year
One target market, one product or service, one conversion tool, one traffic source, one year. Details are in Promise, problems and desires.

## What we challenge
- The post-and-boost cycle. Chasing the algorithm makes noise, not a business.
- False competition. The only comparison that matters is you against you.
- Agencies, gurus and courses that sell reassurance.
- Motion mistaken for progress.

## What we do differently
- We change the question from "how do I get attention?" to "what is my business worth?".
- We build the business first (identity, offer, customers, community, operations). Content becomes a result of it, not the engine.
- The core promise: in 30 weeks, take a business from running on the owner to running on a system.
- We do not help. We do our job so yours gets easier.

## Who it is for
Small, community-driven service businesses: service businesses and event planners (digital), gyms, studios and event halls (physical). Same model from two ends. The owners are stagnant, comfortable and quietly aware something is off. They put their own money in. Their identity is fused with the business. They have likely been burned before.

**Not for** anyone who wants to be reassured, coddled or sold to gently. The copy is allowed to make some readers leave.

### What they fear
- Being seen to fail, by a spouse, an employee, a competitor.
- Admitting the business runs them, not the other way around.
- That years already spent are wasted if they change course.
- Being sold to, again.

### What moves them
- Relief, not hustle. The real dream outcome is "stop feeling like I'm failing quietly".
- Specificity over hype. Small, checkable claims beat big vague ones.
- Being told "you're not ready" often works better than "you qualify".

## The brand in five rules
1. Short sentences do the damage. Long ones explain.
2. Never announce honesty, edge or boldness. Be it.
3. Punch the behaviour, never the person's worth, and hand them a way out in the same breath.
4. The nautical world is the only metaphor world: sea, sail, port, rocks, anchor, drift, crew, ship.
5. Intensity rises as the reader goes deeper. Darker, tighter, bolder. Never softer near the call to action.

## What is in this book
- **Voice**: how we write, banned words, how hard we hit.
- **Visual**: colour, type, layout, the carousel template.
- **Illustration**: the low-poly night world and its characters.
- **Social**: Instagram role, the pinned carousel, the Christmas poem carousel.
- **Promise, problems and desires**: the one-year model, the promise, the three problems and three desires.
- **Solution model brief**: the frame for building the solutions with the first testers.
- **Offer and funnel**: the ladder, CTA escalation, what we sell.
- **Open decisions**: what is still undecided.
