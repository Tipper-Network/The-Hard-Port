# Offer and funnel

## The website ladder
Traffic arrives cold from a short "you vs you" video. The site converts. Every section must earn the next scroll.

1. **Hook (video).** Sets up "you vs you", ends on a line that resolves on the site.
2. **Identity match.** "Your business isn't sinking, it's not going anywhere." Lands in the first 3 seconds of scroll.
3. **Agitation.** The canonical letter.
4. **Mechanism.** Boosting versus a campaign.
5. **Proof.** Honest anti-testimonial stats. The gap in normal proof becomes the proof.
6. **Offer stack.** A ladder, named for how brave the owner is: Port, Sea, Ocean.
7. **Scarcity.** Two free slots a month. We pick, the applicant does not. Real, never a fake timer.
8. **Objections.** Every answer matches the aggression of its question.
9. **Last call.** The hardest line on the page. One call to action, nothing competing.

## Calls to action escalate
Never the same label twice.
- Top: "Watch the truth" / "See the gap"
- Middle: "Show me what I'm doing wrong"
- Near price: "Prove us wrong"
- Bottom: "Stop being fine" / "Apply for the free slot"

## What we sell
**The Port programme:** 30 weeks from running on the owner to running on a system. Five sprints: Structure, Costs, Profit, Clients, Team. Plus a done-for-you website and online presence, 1:1 partnership calls and a community. The prices in the 21 Oct document ($6,000 split, $4,500 in full, then $325 a month) were written for the earlier 23-week version and are not confirmed for 30 weeks. Testers work with us for little money (see Solution model brief). "A transformation, not a course." It starts by diagnosing Point A and moves to a measurable Point B.

**The website tiers (earlier version):**
| Tier | Price | For |
|---|---|---|
| To the Port | custom | People still scared of the water |
| To the Sea | $632 a month | People who want to move |
| To the Ocean | $1,723 a month | People who are done playing small |

These two price structures conflict. See Open decisions.

Right now we are only working on the Port product, and we are looking for the first testers. Sea and Ocean are parked until the Port is proven. Do not show three tiers on the site until then.

## Frameworks behind it
- **Hormozi value equation.** Raise dream outcome and believability. Cut time delay and effort.
- **Godin.** Smallest viable audience. Remarkable over safe. Marketing creates a tension that only action resolves, so nothing mid-page resolves it early.

## Internal rule
A larger network sits behind The Hard Port. Never name it and never explain it publicly. At most one understated line may imply there is a door beyond this one. Silence about it is part of the gatekeeping tone.
