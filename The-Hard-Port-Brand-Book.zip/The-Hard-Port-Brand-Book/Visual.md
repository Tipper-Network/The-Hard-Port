# Visual

## Principles
- Dark, navy-based. No pastels. No generic corporate blue and white.
- Nautical metaphors only. No rockets, lightbulbs or handshakes.
- Intensity rises with depth: darker, tighter, bolder as the reader goes down. A page that looks the same from top to bottom is a bug.
- No stock photography. No soft SaaS cards, default checkmarks or feature grids.
- Hard corners. `radius-0` is the default.

## Colour
- **Ground:** `ink-900`. Panels `ink-700`. Depth `ink-500`.
- **Text:** `off-white`. Captions `text-muted`.
- **Accent:** `rust` for labels, progress and calls to action.
- **Highlight:** `gold`, on one word per screen.
- **Warning:** `magenta` and `alarm`, small areas only.

Proportion on any layout: about 70% navy, 20% off-white, 8% rust, 2% gold.

## Type
- **Anton**, uppercase, for headlines and poem lines. Tracking 0.5px, leading 1.1.
- **IBM Plex Sans** for body.
- **IBM Plex Mono** 500, uppercase, 4px tracking, for labels, counters and handles.

Fonts load from Google Fonts. No font files are stored in this book.

## Logo
An orange sail rising out of navy waves, with THE HARD PORT stacked in three lines of bold sans. The sail is the "hard a-port" turn, the waves are the sea we keep naming.

- **On light grounds:** `thp-logo-primary.png` (navy and orange).
- **On dark grounds:** `thp-logo-on-dark.png` (off-white and orange). The navy wordmark disappears on `ink-900`, so never place the primary version on the night theme.
- **Clear space:** at least the height of the letter T on every side.
- **Minimum size:** 120px wide on screen.
- **Never:** recolour the sail, stretch, tilt, add shadows, put it on photos without a navy scrim, or retype the name in another font beside it.
- **Placement:** top left or bottom left. In carousels the footer stays text (THE HARD PORT in mono). The full logo goes on the first and last slide only.
- **The sail alone:** the sail and waves work as a profile picture and favicon. Cut it from a vector file, not from the PNG.

The logo uses a brighter royal navy (`logo-navy`) and orange (`logo-orange`) than the night palette. Both live side by side for now. See Open decisions.

## The carousel template
Instagram feed, 4:5, **1080 × 1350**.

| Element | Spec |
|---|---|
| Side margin | 80px (`space-6`) |
| Label | top 84px, mono 22px, `rust`, format `0N — THE WORD` |
| Poem or statement | top 132px, Anton uppercase, 62px (50px for two lines), `off-white` with soft text shadow |
| Rhyme or key word | `gold` |
| Top scrim | navy gradient, top 520px, 72% to 0% so text always reads over art |
| Bottom scrim | navy gradient, bottom 260px, 80% to 0% |
| Progress bar | 920px wide, 4px, bottom 96px, `rust` fill over 25% off-white track, gold triangle "sail" at the fill end |
| Footer left | THE HARD PORT, mono 20px |
| Footer centre | @thehardport, mono 20px, `gold` |
| Footer right | `0N / 07` counter |

Text is always live and editable. Art carries no poem text. A few words inside the scene (a sign, a chair tag) are allowed when they are props.
