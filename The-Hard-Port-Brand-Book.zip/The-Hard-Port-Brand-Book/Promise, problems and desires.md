# Promise, problems and desires

## The model, for one year
One target market. One product or service. One conversion tool. One traffic source. One year.

Everything we make serves those five. A post, page or idea that does not serve them waits.

| | Answer | Status |
|---|---|---|
| Target market | Small, community-driven service businesses. **Digital end:** service businesses and event planners. **Physical end:** gyms, studios and event halls. These are also our first testers. | Set. Both ends run the same model. |
| Product or service | **The Port**, the 30-week programme. The only product we are building right now. | **Testing phase.** Testers work with us for little money so we can test the solutions. |
| Conversion tool | A cold call, then a fit conversation. The website application comes later. | Working for the testing phase. Confirm. |
| Traffic source | Cold calling for the testing phase. Instagram builds awareness and trust beside it. | **Open.** Which one is the single source for the year? |
| Time | One year, then we review | Set |

## The one market
Same model, seen from two ends. A gym, a studio, an event hall, an event planner and a small digital service business all sell something people come back to. Each depends on its owner, and each is built on its community. That is why one message and one offer can serve all of them, and why they are a good fit for community building.

## The promise
Everything below hangs off this line.

**In 30 weeks, your business goes from running on you to running on a system.**

The programme is now 30 weeks. This is the working wording. Confirm it, or give us the line you want to be held to.

## Problems
Three problems. Each one is a name, the line the owner says to themselves, the line we say back, and the truth we stand on. The lines we say back are drafts. Edit them freely, but keep them this plain.

### 1. Money: the gap between profit and reality
- **The owner feels:** always in survival mode.
- **We say:** "You're not building. You're surviving."
- **The truth:** a small business is made to add and create, not just stay alive.

### 2. Manual effort: no systems, same problem every day
- **The owner feels:** same problems every day.
- **We say:** "Same problem. Different Tuesday."
- **The truth:** what nobody checks falls to its lowest standard. A system lets everyone in the business connect to the core of the work.

### 3. Friction, trust and chaos: the owner can't step away
- **The owner feels:** I can't step away.
- **We say:** "Leave for a week. See what breaks."
- **The truth:** feeling productive and being productive are not the same thing.

## Desires
Three things the owner wants. Each one is what they want, what we say, and the truth behind it.

### 1. Predictable money
- **The owner wants:** to know what is coming in.
- **We say:** "No more guessing."
- **The truth:** money stops being a surprise once the numbers are rechecked, received and used.

### 2. Control
- **The owner wants:** one word from them to change the course of the flow, and to feel their own effort seen and appreciated.
- **We say:** "Hand on the wheel."
- **The truth:** the owner should steer. Right now the business steers the owner.
- **Word note:** this replaces "leverage", which is on our banned list. "Control" is the plain word. "The wheel" keeps it nautical. We avoid "driver's seat" (a driving image, not a sailing one) and "power" (sounds like hustle talk).

### 3. A quiet head
- **The owner wants:** to respond, not react.
- **We say:** "Quiet head. Steady hand."
- **The truth:** when the work runs on a system, the owner stops firefighting and starts deciding.

## Solutions
**Open.** We have not worked out the solutions yet, and that is deliberate. We will learn them with the first testers of the Port. The five sprints (Structure, Costs, Profit, Clients, Team) are raw material, not the answer. Use the Solution model brief to build each one.

## How it reads on a page
1. **Problem first, hard.** Name the pain in their words. Level 2 or 3.
2. **Desire second, plain.** What life looks like with it fixed. Relief, not hype.
3. **Solution third, short.** The route and the promise. Never soft near the call to action.

Keep every line at the reading level of the owner's own words. If a line needs explaining, cut it.
