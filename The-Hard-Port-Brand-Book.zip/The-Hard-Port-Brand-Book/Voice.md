# Voice

## The canonical letter
The emotional centre of the brand. Everything else is checked against it.

> The sea never cared for a sailor's feelings. Only whether he was prepared.
>
> When you set sail, the sea reminds you you're supposed to be going somewhere. When's the last time you noticed you'd stopped moving with a direction?
>
> Ask yourself the question: Am I where I want to be?
>
> We call you so you don't feel like you're asking for help, because you're not asking for help, you're asking for clarity. We won't help you. We'll just do our job, so yours gets easier.

## Posture
Calm, unshakeable, immune to excuses, drama and ego. A veteran captain, not a cheerleader and not a troll. We do not reassure. We demand clarity and put a system in place.

## Rules
- Second person, always "you".
- Short by default. One idea per line.
- Say it, do not describe it. A line that explains what the brand is, is not that thing.
- Tone escalates as the reader moves down the page or through the carousel. It never flattens and never softens at the call to action.
- Aggression is calibrated. Punch the behaviour, not the worth. Give the person a way out in the same breath. Think good coach, not troll.
- Specific beats big. A number you can check beats an adjective.

## Aggression ladder
| Level | Sounds like | Use for |
|---|---|---|
| 1. Dry | "Fine is the problem." | Openers, captions |
| 2. Pointed | "You stopped moving a while ago." | Body copy, carousels |
| 3. Hard | "Get over yourself. Get some clarity." | Letter, hero sections |
| 4. Line in the sand | "You're not ready. Prove us wrong." | Offers, last call |

The default voice is level 2 to 3. Never start at level 4. Level 4 is for one line, at the very end of a page, offer or carousel. Never end below the level you started, and never soften at the call to action.

## Say / do not say
| Do not | Do |
|---|---|
| "We're passionate about helping you grow" | "We do the work. You do the commitment." |
| "Unlock your potential" | "Stop being fine." |
| "Boost your business" | "Build the business. Content follows." |
| "Learn More" | "Show me what I'm doing wrong" |

## Banned
unlock, leverage, empower, seamless, game-changer, solutions, elevate your, at your fingertips, take your business to the next level, we're passionate about, "Learn More" as a button, boost your business.

"Boosting" is the thing we mock, so it only appears when mocking it.

## Humour
Fun, nonchalant, with bite. The Christmas poem proves the register: rhyme and play on the surface, a hard truth under it. Never jokes at the reader's expense that leave no way out.

## Language
English first. Arabic and mixed use are an open decision (see Open decisions).
