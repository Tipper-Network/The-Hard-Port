# Illustration

## Style
Low-poly night forest. Flat triangular facets lit from the top left. Snow, pines, a ridge line, a spotlight beam or a glow as the focal light. Vignette at the edges. Dark and calm with one warm light source per scene.

Palette is the brand palette: navy ground, teal depth, one warm light (lantern, sunrise, moon). No gradients that look like stock art.

## Characters
Faceless sailors, built from the same low-poly parts. The silhouette and costume tell the story, not a face.

| Character | Meaning | Costume |
|---|---|---|
| **The owner** | The reader. The person the brand talks to. | Red coat, red beanie with a gold pom, teal scarf |
| **The captain** | Hard Port. The crew. | Blue coat, white scarf, white cap with a gold star, gold epaulettes |
| **The promisers** | Everyone who sold the owner words. | Yellow sou'wester, orange slicker, magenta scarf, three identical copies |
| **The ghosts** | Years that passed. | Desaturated, low opacity |

The old nutcracker character was dropped. Do not bring it back.

## Scene rules
- One character set and one setting per slide. Each slide carries one issue.
- The captain appears when we act. The owner appears when they feel it.
- Light tells the story: dark for dread, a lantern for help, sunrise for the new year, moon for the closing.
- Text inside a scene is a prop only (a page, a sign, a tag).
- Output: PNG at 1080 × 1350, text-free, so copy stays editable on top.

## The Christmas set
Seven scenes from the poem. See Social for the map.
