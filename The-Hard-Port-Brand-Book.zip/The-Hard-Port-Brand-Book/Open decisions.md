# Open decisions

## Model and message
18. **The conversion tool.** For the testing phase it is a cold call, then a fit conversation. Confirm, and decide what the website application does later.
19. **The promise wording.** "In 30 weeks, your business goes from running on you to running on a system" is the working line. Confirm or replace.
20. **Tester price and terms.** "Little money" needs a number, what it covers, and what we ask in return (feedback, a case study, a referral).
21. **Number of testers.** How many do we want in this phase, and for how long, before the testing phase ends.
22. **The one traffic source.** Cold calling runs the testing phase. Is Instagram an awareness layer beside it, or is cold calling the single source for the year?
23. **The word for leverage.** We use "Control" and "Hand on the wheel". Confirm.

## Brand
1. **Logo file.** The logo exists but only as a small PNG (253 × 141). We need an SVG or high-resolution file, and a sail-only version for the profile picture.
1b. **Logo colours.** The logo navy (#0A2C75) and orange (#FF6B17) differ from the night palette (#0F2027, #F57C00). Either keep both worlds, or move the brand orange to the logo orange and keep the dark navy only for grounds.
2. **Name story.** Why "The Hard Port"? The "hard a-port" origin is in the brief, but the founder's version is not recorded.
3. **Language.** English only, or English and Arabic.
4. **Tone.** Calm and premium, bold and direct, or raw and personal. Current work leans bold and direct.

## Offer
5. **Pricing.** The website tiers ($632 and $1,723 a month) conflict with the earlier 23-week partnership document ($4,500 or $6,000, plus $325 a month). The programme is now 30 weeks and testers pay little. Set the real price list.
6. **Christmas offer facts.** How many seats, what deadline, what price.
7. **Call to action channel.** Slide 6 says "Click reply". Instagram has no reply. Use a DM keyword, a link in bio, or a booking link.

## Story for the pinned carousel
8. When and where THP started, and the moment it clicked.
9. The Africa story in two or three sentences.
10. Whether the failed companies are public, and the count (7 or 8).
11. Two or three real milestones and any numbers that can be shared.
12. Whether Destructure (the book) belongs in THP's story or stays with the personal brand.
13. Where the testers are: Lebanon, the region, or anywhere. The market is set (see Promise, problems and desires).

## Assets
14. Portrait of Tarek, working shots, an early-days photo, detail shots (notebooks, whiteboards). All with permission.

## Christmas carousel
16. Tighten poem lines 3 and 4, or leave as written.
17. The narration recording. Punctuation of the scenes follows the spoken delivery.
