# Social

## Role of Instagram
Awareness and entertainment. Our content strategy is a **flywheel, not a funnel**. People are invited into our world and want to be part of it. Hard selling belongs to the website, not the feed.

Handle: **@thehardport**, shown in the footer of every carousel slide.

## Content pillars
First principles and systems thinking. AI utility. Design and UX. Entrepreneurial and engineering mindset.

## The pinned carousel (brief)
Sits pinned on the profile. It must cover:
1. What we are challenging in this world.
2. Who we are.
3. What we do differently.
4. Our philosophy and what we have helped with.

Told as a story: a founder who travelled the world, ended up in Lebanon starting a company, learned by helping others, and now only focuses on helping others. The invitation: join the sailing club and get our help. Status: story facts partly collected, open questions listed in Open decisions.

## The Christmas poem carousel
Seven slides, one character and one issue each. Poem lines are live text. In-scene props are baked into the art.

| Slide | Label | Line | Scene |
|---|---|---|---|
| 01 | THE DREAD | It was the months before Christmas and all through the **nights**, / All were dreading the year to end, while questioning their **fights**. | Owner holding an oar in the snow |
| 02 | THE MONTH | I am doing a month only for you, so this year would not be in **flight**. | Captain holds a page, six month pages blow away |
| 03 | THE PROMISERS | Unlike the others where change you promised, with only words to **cite**. | Three identical promisers with empty slogans, owner with arms crossed |
| 04 | THE LIGHT | So by the new year to come, on your work I will shed some **light**, | Captain with a lantern lighting a desk |
| 05 | JANUARY | And in your mind clarity I'll renew, for your January to start **bright**. | Owner at sunrise by a JANUARY signpost |
| 06 | THE SEAT | Click reply if your courage aligns, so we hold a seat for you **tight**. | Captain saluting beside a RESERVED chair and lantern |
| 07 | THE PAST | And ensure that the years that passed, will no longer linger in **spite**. | Captain and owner looking up at the moon |

The slide 6 call to action needs a real channel, since Instagram has no "reply" (see Open decisions).
