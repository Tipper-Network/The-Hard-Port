# Solution model brief

A working brief for building the solutions. Nothing here is decided. It is the frame we fill in with the first testers of the Port.

## The rule
One problem, one change, one number the owner can check. If we cannot say it in a sentence, it is not a solution yet.

## Who tests it
The target market is the first testers. Small, community-driven service businesses from either end: digital (service businesses, event planners) or physical (gyms, studios, event halls). Owners who recognise at least one of the three problems and will commit.

## How testers are found
We are in the testing phase of the 30-week Port programme.

1. **Cold call.** We call small businesses and talk to the owner. We are not selling. We are listening.
2. **Fit conversation.** We find out whether the work we plan to do fits how their business is built.
3. **Test for little money.** If it fits, we work with them for little money. They get real work, we get to test the solution.
4. **Learn and adjust.** What happens with each tester changes the solution, the line and the next call.

### Fit conversation: draft questions
Use their own words. Keep them short.
- What happens in your business when you are away for a week?
- Which problem shows up every day, the same way?
- Do you know what money is coming in next month?
- Who else in the business can make the decision you make?
- If we fixed one thing in 30 weeks, which would it be?

A tester fits when they recognise at least one of the three problems, the owner makes most of the calls, and they will commit to the 30 weeks.

## The questions for each problem
Answer these for each problem, in the owner's words, in this order.

1. **Before.** What does the owner do today, and what does it cost them?
2. **The change.** What is different afterwards? One sentence.
3. **What we install.** The system, routine or tool that makes the change stick.
4. **Who does what.** What we do. What the owner does.
5. **Time.** How long until the owner feels it?
6. **The number.** The one figure the owner can check themselves.
7. **The desire it delivers.** Predictable money, control or a quiet head.
8. **What would make us stop or change it.** The sign it is not working.

## The board
Fill one row per problem as testers teach us.

| Problem | The change | What we install | The number | Time | Desire it delivers | Status |
|---|---|---|---|---|---|---|
| Survival mode (money gap) | | | | | Predictable money | Open |
| Same problems every day (no systems) | | | | | Control | Open |
| Can't step away (friction, chaos) | | | | | A quiet head | Open |

## How we learn
- One change at a time with each tester, so we know what worked.
- After each tester, note what they said in their own words. Their words become the next headline.
- Review the board with the numbers once a month.
- Anything that does not move a number gets cut.

## What feeds the brand
When a solution works, it becomes: a line in our voice, one proof the owner can check, and one more rung of the funnel. Nothing goes on the website until a tester has lived it.
